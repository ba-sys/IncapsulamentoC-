#include <iostream>
#include <iostream>
#include <fstream>
#include <string>
#include <bitset>
#include "funzioni.h"
using namespace std;



int main()
{
    string NomeFileInput = "Messaggio.txt";
    string NomeFileOutput = "Frame.txt";
    string ContenutoFileOutput = "";
    string ContenutoFileInput = LeggiMessaggio(NomeFileInput);
    OutputMessaggio(ContenutoFileInput);
    ContenutoFileInput = stringToBin(ContenutoFileInput);
    IpHeader Packet;
    char Tos[8] = {'0','0','0','0','0','0','0','0'};
    //char Flags[3] = {'0','0','0'};
    int Source[4] = {192, 168, 1, 100};
    int Destination[4] = {192, 168, 50, 25};
    //char OC[2] = {'0', '0'};
    //char ON[5] = {'0', '0', '0', '0', '0'};
    creaDatagram(Packet, Tos, /*0, Flags, 0, */ 64, 6, Source, Destination, /*3, '0', OC, ON, */ ContenutoFileInput);
    ContenutoFileOutput = creaDatagramStringa(Packet);
    ScritturaMessaggio(ContenutoFileOutput, NomeFileOutput);

    return 0;
}
