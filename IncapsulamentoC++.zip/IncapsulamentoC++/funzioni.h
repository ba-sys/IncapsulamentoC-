#ifndef FUNZIONI_H_INCLUDED
#define FUNZIONI_H_INCLUDED
#include <iostream>
#include <fstream>
#include <string>
#include <bitset>
#include <cstdlib>
#include <ctime>
using namespace std;

struct S_TOS{
    char Precedence [3];
    char Delay;
    char Troghput;
    char Reliability;
    char Monetaty_Cost;
    char Unused;
};

struct S_Flags{
    char Unused;
    char DF;
    char MF;
};

struct S_Options{
    char CF;
    char OC [2];
    char ON [5];
    S_Options *next;
};

struct IpHeader{
    char Version [4];
    char HLEN [4];
    S_TOS ToS;
    char Total_Length[16];
    char ID[16];
    S_Flags Flags;
    char Fragment_Offset[13];
    char TTL[8];
    char Protocol[8];
    char Header_Checksum[16];
    char Source_Address[4][8];
    char Destination_Address[4][8];
    S_Options Option;
    string Payload;
};

inline void ConvertiIntBinario(int numero, char Array[], size_t dimArray){
    string Binario = "";
    while((sizeof(Array)/sizeof(char))<dimArray){
        Array[(dimArray-1) -(sizeof(Array)/sizeof(char))] = char(numero % 2);
        numero/=2;
    }
}


//Funzione che legge il contenuto del file//
inline string LeggiMessaggio(string NomeFile){
    string Contenuto;
    ifstream file(NomeFile);
    if (!file){
        cout<<"file non trovato, procedendo nella sua creazione"<<endl;
        ofstream file(NomeFile);
    }
    file >> Contenuto;  //istruzione di lettura
    if (!file.eof()){
        cout<<"errore nella lettura del file"<<endl;
    }
    file.close();
    return Contenuto;
}

//Funzione che scrive il contenuto sul file//
inline void ScritturaMessaggio(string Contenuto, string NomeFile){
    ofstream file(NomeFile);
    if (file){
        file << Contenuto;  //istruzione di scrittura//
        file.close();
    } else {
        cout<<"errore durante la scrittura"<<endl;
    }
    file.close();
}

//Funzione di input del contenuto//
inline string InputMessaggio(int LunghezzaMax){
    string Messaggio;
    cout<<"inserire il nuovo messaggio da scrivere (massimo "<<LunghezzaMax<<" caratteri senza spazi):"<<endl;
    cin>>Messaggio;
    while (Messaggio.size() > LunghezzaMax){
        cout<<"Messaggio troppo lungo, reinserire"<<endl;
        cin>>Messaggio;
    }
    while (Messaggio.size() < LunghezzaMax) Messaggio += char(0);
    return Messaggio;
}

//Funzione di stampa del contenuto//
inline void OutputMessaggio(string Messaggio){
    if (Messaggio != "") cout<<"Il messaggio attuale: "<<Messaggio<<endl;
    else cout<<"non ce nessun messaggio"<<endl;
}

inline string charToBin(char c){
    bitset<8> cBinario(c);
    return cBinario.to_string();
}

//Funzione che converte da stringa a "binario"//
inline string stringToBin(string Stringa){
    string Binario = "";
    //si crea un bitset per ogni carattere per poi aggiungerla alla stringa del messaggio//
    for (char c : Stringa){
        Binario += charToBin(c);
    }
    return Binario;
}

inline string binToString(string Binario){
    string Stringa = "";
    //per ogni ottetto di bit di un carattere lo si converte prima in un long unsigned per ottenere una conversione da binario a intero e poi lo si trasforma in char con static_cast//
    for (int i = 0; i < Binario.length(); i+=8){
        bitset<8> cbitset (Binario.substr(i, 8));
        char c = static_cast<char>(cbitset.to_ulong());
        Stringa += c;
    }
    return Stringa;
}

inline void creaDatagram(IpHeader Packet, char TOS[], int ID, char Flags[], size_t Precedent, int TTL, int Protocol, char Source[4][8], char Destination[4][8]){
    Packet.Version[0] = '0';
    Packet.Version[1] = '1';
    Packet.Version[2] = '0';
    Packet.Version[3] = '0';
    for (int i=0; i<3; i++) Packet.ToS.Precedence[i] = TOS[i];
    Packet.ToS.Delay = TOS[3];
    Packet.ToS.Troghput = TOS[4];
    Packet.ToS.Reliability = TOS[5];
    Packet.ToS.Monetaty_Cost = TOS[6];
    Packet.ToS.Unused = TOS[7];
    ConvertiIntBinario(ID, Packet.ID, 16);
    Packet.Flags.Unused = Flags[0];
    Packet.Flags.MF = Flags[1];
    Packet.Flags.DF = Flags[2];
    ConvertiIntBinario(int(Precedent), Packet.Fragment_Offset, 13);
    ConvertiIntBinario(TTL, Packet.TTL, 8);
    ConvertiIntBinario(TTL, Packet.Protocol, 8);
    srand(time(0));
    for(int i=0; i<16; i++) Packet.Header_Checksum[i] = char(rand() % 2);
    int Tmp_Source_Address[8]; int Tmp_Destination_Address[8];
    for(int i=0; i<4; i++){
        for (int j=0; j<8; j++){
            Tmp_Source_Address[j] = Source[i][j];
            Tmp_Destination_Address[j] = Destination[i][j];
        }
        (Tmp_Source_Address, Packet.Source_Address, 8);
        (Tmp_Destination_Address, Packet.Destination_Address, 8);
    }
}


#endif
