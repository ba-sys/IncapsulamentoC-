#ifndef FUNZIONI_H_INCLUDED
#define FUNZIONI_H_INCLUDED
#include <iostream>
#include <fstream>
#include <string>
#include <bitset>
#include <cstdlib>
#include <ctime>
using namespace std;

//Campi del Type Of Service
struct S_TOS{
    char Precedence [3];
    char Delay;
    char Troghput;
    char Reliability;
    char Monetaty_Cost;
    char Unused;
};

//Campi Flags
/*struct S_Flags{
    char Unused;
    char DF;
    char MF;
};*/

//Lista di opzioni
/*struct S_Options{
    char CF;
    char OC [2];
    char ON [5];
    S_Options *next;
};*/

//Campi del Header IP
struct IpHeader{
    char Version [4];
    char HLEN [4];
    S_TOS ToS;
    char Total_Length[16];
    //char ID[16];
    //S_Flags Flags;
    //char Fragment_Offset[13];
    char TTL[8];
    char Protocol[8];
    char Header_Checksum[16];
    char Source_Address[4][8];
    char Destination_Address[4][8];
    //S_Options *Options;
    string Payload;
};

//Funzione che converte numero decimale in array di char che sono i bit
inline void ConvertiIntBinario(int Number, char Array[], size_t dimArray){
    for(int i=0; i<dimArray; i++){
        Array[dimArray-1-i] = (char)(Number % 2);
        Number/=2;
    }
}

//Conversione dell'indirizzo IP da decimale a binario
inline void IndirizzoIntBinario(char Address[4][8], int Numbers[4]){
    for(int i=0; i<4; i++){
        for(int j=7; j>=0; j--){
            Address[i][j] = (char)(Numbers[i] % 2);
            Numbers[i]/=2;
        }
    }
}

//Creazione della lista dinamica delle opzioni
/*inline void CreaOpzioni(S_Options *&Testa, int NumElementi, char CF, char OC[], char ON[]){
    S_Options *Tmp = Testa;
    for (int i=0; i<NumElementi; i++){
        if(Testa == NULL){
            Testa = new S_Options;
            Testa->CF = CF;
            for(int i=0; i<2; i++) Testa->OC[i] = OC[i];
            for(int i=0; i<5; i++) Testa->ON[i] = ON[i];
            Testa->next = NULL;
            Tmp = Testa->next;
        }else{
            Tmp = new S_Options;
            Tmp->CF = CF;
            for(int i=0; i<2; i++) Tmp->OC[i] = OC[i];
            for(int i=0; i<2; i++) Tmp->ON[i] = ON[i];
            Tmp->next = NULL;
            Tmp = Tmp->next;
        }
    }
}*/

//Restituisce la dimensione dellla lista dinamica delle opzioni
/*inline size_t RestituireDim(S_Options *Testa){
    S_Options *Tmp = Testa;
    size_t Count =0;
    while(Tmp!=NULL){
        Tmp=Tmp->next;
        Count++;
    }
    return Count;
}*/

//Funzione che legge il contenuto del file//
inline string LeggiMessaggio(string NomeFile){
    string Contenuto;
    ifstream file(NomeFile);
    if (!file){
        cout<<"file non trovato, procedendo nella sua creazione"<<endl;
        ofstream file(NomeFile);
    }
    file >> Contenuto;  //istruzione di lettura
    if (file.fail()){
        cout<<"errore nella lettura del file"<<endl;
    }
    file.close();
    return Contenuto;
}

//Funzione che scrive il contenuto sul file//
inline void ScritturaMessaggio(string Contenuto, string NomeFile){
    ofstream file(NomeFile);
    if (file){
        file << Contenuto;  //istruzione di scrittura//
    } else {
        cout<<"errore durante la scrittura"<<endl;
    }
    file.close();
}

//Funzione di input del contenuto//
inline string InputMessaggio(int LunghezzaMax){
    string Messaggio;
    cout<<"inserire il nuovo messaggio da scrivere (massimo "<<LunghezzaMax<<" caratteri senza spazi):"<<endl;
    cin>>Messaggio;
    while (Messaggio.size() > LunghezzaMax){
        cout<<"Messaggio troppo lungo, reinserire"<<endl;
        cin>>Messaggio;
    }
    while (Messaggio.size() < LunghezzaMax) Messaggio += '0';
    return Messaggio;
}

//Funzione di stampa del contenuto//
inline void OutputMessaggio(string Messaggio){
    if (Messaggio != "") cout<<"Il messaggio attuale: "<<Messaggio<<endl;
    else cout<<"non ce nessun messaggio"<<endl;
}

inline string charToBin(char c){
    bitset<8> cBinario(c);
    return cBinario.to_string();
}

//Funzione che converte da stringa a "binario"//
inline string stringToBin(string Stringa){
    string Binario = "";
    //si crea un bitset per ogni carattere per poi aggiungerla alla stringa del messaggio//
    for (char c : Stringa){
        Binario += charToBin(c);
    }
    return Binario;
}

inline string binToString(string Binario){
    string Stringa = "";
    //per ogni ottetto di bit di un carattere lo si converte prima in un long unsigned per ottenere una conversione da binario a intero e poi lo si trasforma in char con static_cast//
    for (int i = 0; i < Binario.size(); i+=8){
        bitset<8> cbitset (Binario.substr(i, 8));
        char c = static_cast<char>(cbitset.to_ulong());
        Stringa += c;
    }
    return Stringa;
}

inline void creaDatagram(IpHeader Packet, char TOS[], /*int ID, char Flags[], size_t Precedent, */ int TTL, int Protocol,
int Source[4], int Destination[4], /*int NumOpzioni, char OpzioniCF, char OpzioniOC[2], char OpzioniON[5], */ string Payload){
    Packet.Payload = Payload;
    Packet.Version[0] = '0';
    Packet.Version[1] = '1';
    Packet.Version[2] = '0';
    Packet.Version[3] = '0';
    for (int i=0; i<3; i++) Packet.ToS.Precedence[i] = TOS[i];
    Packet.ToS.Delay = TOS[3];
    Packet.ToS.Troghput = TOS[4];
    Packet.ToS.Reliability = TOS[5];
    Packet.ToS.Monetaty_Cost = TOS[6];
    Packet.ToS.Unused = TOS[7];
    /*ConvertiIntBinario(ID, Packet.ID, 16);
    Packet.Flags.Unused = Flags[0];
    Packet.Flags.MF = Flags[1];
    Packet.Flags.DF = Flags[2];
    ConvertiIntBinario(int(Precedent), Packet.Fragment_Offset, 13);*/
    ConvertiIntBinario(TTL, Packet.TTL, 8);
    ConvertiIntBinario(TTL, Packet.Protocol, 8);
    srand(time(0));
    for(int i=0; i<16; i++) Packet.Header_Checksum[i] = (char)(rand() % 2);
    IndirizzoIntBinario(Packet.Source_Address, Source);
    IndirizzoIntBinario(Packet.Destination_Address, Destination);
    //Packet.Options = NULL;
    //CreaOpzioni(Packet.Options, NumOpzioni, OpzioniCF, OpzioniOC, OpzioniON);
    ConvertiIntBinario(/*int(RestituireDim(Packet.Options))*/ +20, Packet.HLEN, 4);
    ConvertiIntBinario(/*int(RestituireDim(Packet.Options))*/ +20 + Packet.Payload.size(), Packet.Total_Length, 16);
}

inline string creaDatagramStringa(IpHeader Packet){
    string Impacchettato = "";
    for(int i=0; i<4; i++) Impacchettato += Packet.Version[i];
    for(int i=0; i<4; i++) Impacchettato += Packet.HLEN[i];
    for (int i=0; i<3; i++) Impacchettato += Packet.ToS.Precedence[i];
    Impacchettato += Packet.ToS.Delay;
    Impacchettato += Packet.ToS.Troghput;
    Impacchettato += Packet.ToS.Reliability;
    Impacchettato += Packet.ToS.Monetaty_Cost;
    Impacchettato += Packet.ToS.Unused;
    for(int i=0; i<16; i++) Impacchettato += Packet.Total_Length[i];
    /*for(int i=0; i<16; i++) Impacchettato += Packet.ID[i];
    Impacchettato += Packet.Flags.Unused;
    Impacchettato += Packet.Flags.MF;
    Impacchettato += Packet.Flags.DF;
    for(int i=0; i<13; i++) Impacchettato += Packet.Fragment_Offset[i];*/
    for(int i=0; i<8; i++) Impacchettato += Packet.TTL[i];
    for(int i=0; i<8; i++) Impacchettato += Packet.Protocol[i];
    for(int i=0; i<16; i++) Impacchettato += Packet.Header_Checksum[i];
    for(int i=0; i<4; i++){
        for(int j=0; j<8; j++) Impacchettato += Packet.Source_Address[i][j];
    }
    for(int i=0; i<4; i++){
        for(int j=0; j<8; j++) Impacchettato += Packet.Destination_Address[i][j];
    }
    /*S_Options *tmp = Packet.Options;
    while(tmp!=NULL){
        Impacchettato += tmp->CF;
        for(int i=0; i<2; i++) Impacchettato += tmp->OC[i];
        for(int i=0; i<5; i++) Impacchettato += tmp->ON[i];
        tmp=tmp->next;
    }
    Impacchettato += Packet.Payload;*/
    return Impacchettato;
}

#endif
