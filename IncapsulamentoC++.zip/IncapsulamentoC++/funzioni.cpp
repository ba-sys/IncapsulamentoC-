#include <iostream>
#include <iostream>
#include <fstream>
#include <string>
#include <bitset>
#include "funzioni.h"
using namespace std;



int main()
{

    return 0;
}
